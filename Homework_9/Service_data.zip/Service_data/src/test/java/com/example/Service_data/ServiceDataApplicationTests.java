package com.example.Service_data;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
